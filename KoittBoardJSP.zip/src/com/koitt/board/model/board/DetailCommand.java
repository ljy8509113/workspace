package com.koitt.board.model.board;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.koitt.board.dao.BoardDao;
import com.koitt.board.model.Command;
import com.koitt.board.vo.Board;

public class DetailCommand implements Command{
	
	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException, IllegalArgumentException, NullPointerException {
		String page = "./board/detail.jsp";
		BoardDao dao = new BoardDao();
		
		String no = req.getParameter("no");
		
		if(no == null || no.trim().length() == 0)
			throw new IllegalArgumentException("�Խù� ��ȣ ����");
		
		Board b = dao.select(Integer.parseInt(no));
		if(b == null)
			throw new NullPointerException("���ų� ������ �Խù� �Դϴ�.");
		
		req.setAttribute("detail", b);
		
		return page;
	}
	
}
