package com.koitt.board.model.board;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.koitt.board.dao.BoardDao;
import com.koitt.board.model.Command;
import com.koitt.board.vo.Board;

public class UpdateCommand implements Command{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException, IllegalArgumentException, NullPointerException {
		String page = "./board/update-ok.jsp";
		
		String no = req.getParameter("no");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		
		if(no == null || no.trim().length() == 0)
			throw new IllegalArgumentException("�Խù� ��ȣ ����");
		
		BoardDao dao = new BoardDao();
		Board b = dao.select(Integer.parseInt(no));
		if(b == null)
			throw new NullPointerException("���ų� ������ �Խù� �Դϴ�.");
		
		Board board = new Board();
		board.setNo(Integer.parseInt(no));
		board.setContent(content);
		board.setTitle(title);
		
		dao.update(board);
		
		return page;
	}
	
}
