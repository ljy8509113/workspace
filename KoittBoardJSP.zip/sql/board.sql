--DDL(Data Definition Language)
drop table board;

create table board(
	no			int not null primary key auto_increment,
	title 		varchar(30) not null,
	content 	varchar(255) null,
	writer 	varchar(10) not null,
	regdate	date not null
);

--DML(Data Manipulation Language)
insert into board(title, content, writer, regdate) values('title - 1', 'body - 1', 'writer1', STR_TO_DATE('2018-02-01', '%Y-%m-%d'));
insert into board(title, content, writer, regdate) values('title - 2', 'body - 2', 'writer2', STR_TO_DATE('2018-02-01', '%Y-%m-%d'));
insert into board(title, content, writer, regdate) values('title - 3', 'body - 3', 'writer3', STR_TO_DATE('2018-02-01', '%Y-%m-%d'));

--DQL(Data Query Language)
select * from board;