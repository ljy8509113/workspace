package com.koitt.board.model.users;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.koitt.board.dao.UsersDao;
import com.koitt.board.model.Command;
import com.koitt.board.vo.Users;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class JoinCommand implements Command{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException {
		String page = "./users/join-ok.jsp";
		
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		String passwordConfirm = req.getParameter("password-confirm");
		
		if(!password.equals(passwordConfirm))
			return "./users/join.jsp?error=password";
		
		Users user = new Users(name, email, password);
		
		try {
			UsersDao dao = new UsersDao();
			dao.insert(user);
		}catch(MySQLIntegrityConstraintViolationException e) {
			return "./users/join.jsp?error=email";
		}
		
		return page;
	}
	
}
