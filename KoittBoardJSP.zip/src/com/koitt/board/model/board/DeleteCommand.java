package com.koitt.board.model.board;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.koitt.board.dao.BoardDao;
import com.koitt.board.model.Command;

public class DeleteCommand implements Command{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException {
		String page = "./board/delete.jsp";
		
		String no = req.getParameter("no");
		
		if(no == null || no.trim().length() == 0)
			throw new IllegalArgumentException("�Խù� ��ȣ ����");
		
		BoardDao dao = new BoardDao();
		dao.delete(Integer.parseInt(no));
		
		return page;
	}
	
}
