package com.koitt.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.koitt.board.util.DBUtil;
import com.koitt.board.vo.Board;
import com.koitt.board.vo.Users;

public class UsersDao {
	
	public List<Users> selectAll() throws SQLException, ClassNotFoundException{
		Connection db = DBUtil.getInstance().getConnection();
		
		String sql = "select * from users order by no desc";
		PreparedStatement pstmt = db.prepareStatement(sql);
		
		ResultSet res = pstmt.executeQuery();
		List<Users> list = new ArrayList<Users>();
		
		while(res.next()) {
			Users user = new Users(res.getString("name"), res.getString("email"), res.getString("password"));
			user.setNo(res.getInt("no"));
			list.add(user);
		}
		
		DBUtil.getInstance().close(res, pstmt, db);
		
		return list;
	}
	
	public Users select(String email) throws SQLException, ClassNotFoundException{
		Connection db = DBUtil.getInstance().getConnection();
		
		String sql = "select * from users where email=?";
		PreparedStatement pstmt = db.prepareStatement(sql);
		pstmt.setString(1, email);
		ResultSet res = pstmt.executeQuery();
		
		Users user = null;
		while(res.next()) {
			user = new Users(res.getString("name"), res.getString("email"), "");
			user.setNo(res.getInt("no"));
			
		}
		
		DBUtil.getInstance().close(res, pstmt, db);
		
		return user;
	}
	
	public void insert(Users user) throws SQLException, ClassNotFoundException {
		Connection conn = DBUtil.getInstance().getConnection();
		String sql = "insert into users(name, password, email) values(?,?,?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, user.getName());
		pstmt.setString(2, user.getPassword());
		pstmt.setString(3, user.getEmail());
		
		pstmt.executeUpdate();
		DBUtil.getInstance().close(null, pstmt, conn);	
	}
	
	public boolean matches(String email, String password) throws SQLException, ClassNotFoundException{
		Connection conn = DBUtil.getInstance().getConnection();
		
		String sql = "select * from users where email=? and password=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, email);
		pstmt.setString(2, password);
		ResultSet res = pstmt.executeQuery();
		
		boolean isMatch = res.next();
		DBUtil.getInstance().close(null, pstmt, conn);
		
		return isMatch;
		
	}
	
}
