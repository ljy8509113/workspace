package com.koitt.board.model.users;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.koitt.board.dao.UsersDao;
import com.koitt.board.model.Command;
import com.koitt.board.vo.Users;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class LoginCommand implements Command{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException {
//		String page = "./users/list.jsp";
		
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		
		UsersDao dao = new UsersDao();
		
		if(dao.select(email) == null) {
			//����� �������� ����.
			return "./users/login-form.jsp?error=email";
		}
		
		if(dao.matches(email, password)) {
			HttpSession session = req.getSession();
			session.setAttribute("email", email);
			return "./BoardServlet?cmd=CMD_LIST";
		}else {
			return "./users/login-form.jsp?error=matches";
		}
			
		
//		}catch(MySQLIntegrityConstraintViolationException e) {
//			return "./users/join.jsp?error=email";
//		}
		
//		return page;
	}
	
}
