package com.koitt.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.koitt.board.util.DBUtil;
import com.koitt.board.vo.Board;

public class BoardDao {
	
	public List<Board> selectAll() throws ClassNotFoundException, SQLException{
		Connection db = DBUtil.getInstance().getConnection();
		
		String sql = "select * from board order by no desc";
		PreparedStatement pstmt = db.prepareStatement(sql);
		
		ResultSet res = pstmt.executeQuery();
		List<Board> list = new ArrayList<Board>();
		while(res.next()) {
			Board b = new Board();
			b.setContent(res.getString("content"));
			b.setNo(res.getInt("no"));
			b.setRegdate(res.getDate("regdate"));
			b.setTitle(res.getString("title"));
			b.setWriter(res.getString("writer"));
			list.add(b);
		}
		
		DBUtil.getInstance().close(res, pstmt, db);
		return list;
	}
	
	public Board select(Integer no) throws ClassNotFoundException, SQLException {
		Connection conn = DBUtil.getInstance().getConnection();
		
		String sql = "select * from board where no=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, no);
		
		ResultSet res = pstmt.executeQuery();
		Board b = new Board();
		
		res.next();
		b.setContent(res.getString("content"));
		b.setNo(res.getInt("no"));
		b.setRegdate(res.getDate("regdate"));
		b.setTitle(res.getString("title"));
		b.setWriter(res.getString("writer"));			
		
		DBUtil.getInstance().close(res, pstmt, conn);
		return b;
	}
	
	public void insert(Board board) throws SQLException, ClassNotFoundException {
		Connection conn = DBUtil.getInstance().getConnection();
		String sql = "insert into board(title, content, writer, regdate) values(?,?,?,CURDATE())";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, board.getTitle());
		pstmt.setString(2, board.getContent());
		pstmt.setString(3, board.getWriter());
		
		pstmt.executeUpdate();
		DBUtil.getInstance().close(null, pstmt, conn);		
	}
	
	public void delete(Integer no) throws ClassNotFoundException, SQLException {
		Connection conn = DBUtil.getInstance().getConnection();
		String sql = "delete from board where no=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, no);
		pstmt.executeUpdate();
		DBUtil.getInstance().close(null, pstmt, conn);	
	}
	
	public void update(Board board) throws SQLException, ClassNotFoundException {
		Connection conn = DBUtil.getInstance().getConnection();
		String sql = "update board set title=?, content=? where no=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, board.getTitle());
		pstmt.setString(2, board.getContent());
		pstmt.setInt(3, board.getNo());
		
		pstmt.executeUpdate();
		DBUtil.getInstance().close(null, pstmt, conn);
		
	}
	
}
