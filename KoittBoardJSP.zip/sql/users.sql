
drop table users;

CREATE TABLE users (
	no int not null AUTO_INCREMENT,
	name varchar(255) not null,
	password varchar(255) not null,
	email varchar(255) not null unique key,
	primary key(no)
	);

desc users;

insert into users(name, password, email) values('Tester1','1234','test1@gmail.com');
insert into users(name, password, email) values('Tester2','0000','test2@naver.com');
insert into users(name, password, email) values('�ѱ���','12345','testKorea@korea.co.kr');

select * from users;

select * from users where email="123@email.com";

